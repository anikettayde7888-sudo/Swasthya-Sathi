# स्वास्थ्य साथी — Android Prototype

यह एक शुरुआती educational prototype है। इसमें sexual/reproductive health के सामान्य विषयों पर हिंदी सामग्री है।

## चलाने के लिए
1. Android Studio में इस folder को खोलें।
2. Gradle sync होने दें।
3. Emulator या Android फोन चुनें।
4. Run दबाएँ।

## अगला चरण
- Anonymous Q&A
- Search
- Hindi/English toggle
- अधिक medically reviewed content
- Privacy policy और consent screens
- डॉक्टर/health-centre resources
- Content management/admin panel

नोट: Production app में medical content को qualified healthcare professionals से review कराना चाहिए।

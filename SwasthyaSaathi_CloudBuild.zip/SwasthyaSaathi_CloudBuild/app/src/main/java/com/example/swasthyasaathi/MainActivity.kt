package com.example.swasthyasaathi

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class Topic(val title: String, val text: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val topics = listOf(
        Topic("सहमति (Consent)", "हर यौन संबंध में दोनों लोगों की स्पष्ट, स्वेच्छिक और लगातार सहमति जरूरी है। किसी भी समय सहमति वापस ली जा सकती है। दबाव या मजबूरी सहमति नहीं है।"),
        Topic("गर्भनिरोधक", "कंडोम और अन्य गर्भनिरोधक तरीकों के बारे में सही जानकारी लें। गर्भनिरोधक का चुनाव व्यक्ति की जरूरत और स्वास्थ्य स्थिति के अनुसार होना चाहिए।"),
        Topic("STI/STD से बचाव", "कुछ यौन संक्रमण बिना लक्षणों के भी हो सकते हैं। कंडोम का सही उपयोग और जरूरत पड़ने पर टेस्ट कराना जोखिम कम करने में मदद करता है।"),
        Topic("मासिक धर्म और प्रजनन स्वास्थ्य", "मासिक धर्म सामान्य जैविक प्रक्रिया है। बहुत अधिक दर्द, असामान्य रक्तस्राव या लगातार समस्या होने पर स्वास्थ्यकर्मी से सलाह लें।"),
        Topic("कब डॉक्टर से मिलें?", "तेज दर्द, घाव/असामान्य स्राव, पेशाब में दर्द, बुखार या यौन स्वास्थ्य को लेकर चिंता हो तो योग्य डॉक्टर या स्वास्थ्य केंद्र से सलाह लें।")
    )

    var selected by remember { mutableStateOf<Topic?>(null) }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("स्वास्थ्य साथी", fontWeight = FontWeight.Bold) },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        ) { padding ->
            if (selected == null) {
                LazyColumn(
                    modifier = Modifier.padding(padding).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Text(
                            "यौन एवं प्रजनन स्वास्थ्य",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(6.dp))
                        Text("विश्वसनीय, सम्मानजनक और शैक्षिक जानकारी। यह ऐप डॉक्टर की सलाह का विकल्प नहीं है।")
                        Spacer(Modifier.height(12.dp))
                    }
                    items(topics) { topic ->
                        ElevatedCard(
                            onClick = { selected = topic },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(18.dp)) {
                                Text(topic.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.height(4.dp))
                                Text("जानकारी पढ़ें →")
                            }
                        }
                    }
                    item {
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { selected = Topic("महत्वपूर्ण सूचना", "यह prototype केवल सामान्य health education के लिए है। व्यक्तिगत diagnosis या treatment के लिए qualified healthcare professional से संपर्क करें।") },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("सुरक्षा और गोपनीयता") }
                    }
                }
            } else {
                Column(Modifier.padding(padding).padding(20.dp)) {
                    Text("← वापस", modifier = Modifier.padding(bottom = 20.dp))
                    Text(selected!!.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(16.dp))
                    Text(selected!!.text, style = MaterialTheme.typography.bodyLarge)
                    Spacer(Modifier.height(24.dp))
                    Button(onClick = { selected = null }) { Text("वापस जाएँ") }
                }
            }
        }
    }
}

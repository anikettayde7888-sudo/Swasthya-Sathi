# मोबाइल से APK बनाने का तरीका

यह project cloud build के लिए तैयार है।

## GitHub Actions तरीका

1. GitHub पर नया repository बनाएं।
2. इस पूरे project की files upload करें।
3. `main` branch में files push होने के बाद **Actions** खोलें।
4. **Build Android APK** workflow चुनें और **Run workflow** दबाएं।
5. Build पूरा होने पर workflow के **Artifacts** में `SwasthyaSaathi-debug-apk` मिलेगा।
6. APK डाउनलोड करके Android फोन में install करें।

## ध्यान दें
- Debug APK testing के लिए है।
- Production/Play Store release के लिए signed release build और privacy policy आदि की जरूरत होगी।
- Medical content को qualified healthcare professional से review कराना चाहिए।
